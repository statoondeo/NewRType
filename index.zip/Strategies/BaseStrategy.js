class BaseStrategy {
    constructor(gameObject) {
        this.gameObject = gameObject;        
    }

    update(dt) {

    }
}
class DummyCommand {
    constructor() {
    }

    getClone() {
        return new DummyCommand();
    }

    update(dt) { 
    }

    execute() {
    }
}
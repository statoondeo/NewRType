class GameObjectPartition {
    // Partition netre les objets pour limiter les tests de collision
    static PLAYER_PARTITION = "PLAYER";
    static GAME_PARTITION = "GAME";
    static NEUTRAL_PARTITION = "NEUTRAL";
}

class BaseShape extends GameObject {
    constructor(color) {
        super();
        this.color = color;
    }

    update(dt) {
        super.update(dt);
    }
}

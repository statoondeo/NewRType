class GameObjectState {
    // Différentes états que peut prendre un gameObject
    static IDLE = "IDLE";
    static ACTIVE = "ACTIVE";
    static OUTDATED = "OUTDATED";
}

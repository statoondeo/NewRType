class GameObjectType {
    // Différentes type de gameObjects
    static NONE = "NONE";
    static SHIP = "SHIP";
    static MISSILE = "MISSILE";
    static BONUS = "BONUS";
}

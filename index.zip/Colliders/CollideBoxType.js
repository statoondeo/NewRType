class CollideBoxType {
    static NONE = "NONE";
    static CIRCLE = "CIRCLE";
    static RECT = "RECT";
    static COMPOSITE = "COMPOSITE";
    static QUADRANT = "QUADRANT";
}